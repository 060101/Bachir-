(function () {
'use strict';

/* ================= helpers ================= */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
function el(tag, attrs) {
  const e = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (let i = 2; i < arguments.length; i++) {
    const kids = [].concat(arguments[i]);
    for (const kid of kids) {
      if (kid == null || kid === false) continue;
      e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
  }
  return e;
}
function icon(name) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('class', 'i');
  const u = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  u.setAttribute('href', '#i-' + name);
  s.append(u);
  return s;
}
const mem = {};
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? (k in mem ? mem[k] : d) : JSON.parse(v); } catch (e) { return k in mem ? mem[k] : d; } },
  set(k, v) { mem[k] = v; try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* memory only */ } }
};
let sessMem = null;
const sess = {
  get() { try { const v = sessionStorage.getItem('mb.sess'); return v ? JSON.parse(v) : sessMem; } catch (e) { return sessMem; } },
  set(v) { sessMem = v; try { if (v) sessionStorage.setItem('mb.sess', JSON.stringify(v)); else sessionStorage.removeItem('mb.sess'); } catch (e) { /* memory only */ } }
};
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
function safeUrl(u) {
  if (!u || typeof u !== 'string') return '';
  try {
    const x = new URL(u.trim());
    if (x.protocol === 'http:') x.protocol = 'https:';
    return x.protocol === 'https:' ? x.href : '';
  } catch (e) { return ''; }
}
function clean(s) { return String(s == null ? '' : s).replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 300); }
function norm(s) { return String(s || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '').slice(0, 70); }
function lucene(q) { return q.replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim(); }

let toastT = 0;
function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (bad ? ' bad' : '');
  t.hidden = false;
  clearTimeout(toastT);
  toastT = setTimeout(() => { t.hidden = true; }, 3200);
}

/* ================= sound ================= */
const Snd = {
  ctx: null,
  on: store.get('mb.snd', true) !== false,
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {}); return; }
    try { const C = window.AudioContext || window.webkitAudioContext; if (C) this.ctx = new C(); } catch (e) { /* no audio */ }
  },
  tone(f, d, type, v, at, to) {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime + (at || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f, t);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t + d);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(v || 0.1, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(c.destination);
    o.start(t); o.stop(t + d + 0.02);
  },
  play(name) {
    if (!this.on || !this.ctx) return;
    switch (name) {
      case 'key': this.tone(1040, 0.05, 'square', 0.035, 0, 780); this.tone(260, 0.09, 'triangle', 0.1, 0, 170); break;
      case 'ok': [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.16, 'sine', 0.09, i * 0.075)); break;
      case 'err': this.tone(190, 0.2, 'sawtooth', 0.06, 0, 110); this.tone(150, 0.22, 'square', 0.035, 0.06, 90); break;
      case 'open': this.tone(300, 0.2, 'triangle', 0.09, 0, 900); this.tone(1300, 0.14, 'sine', 0.04, 0.1, 1700); break;
      case 'close': this.tone(720, 0.16, 'triangle', 0.08, 0, 260); break;
      case 'page': this.tone(1600, 0.045, 'sawtooth', 0.018, 0, 480); break;
      default: this.tone(880, 0.06, 'triangle', 0.1, 0, 600); this.tone(220, 0.06, 'sine', 0.07, 0, 150);
    }
  },
  set(on) {
    this.on = !!on; store.set('mb.snd', this.on);
    const b = $('#btnSound'); b.setAttribute('aria-pressed', String(this.on));
    b.firstElementChild.firstElementChild.setAttribute('href', this.on ? '#i-sound' : '#i-mute');
    const s = $('#setSound'); s.setAttribute('aria-pressed', String(this.on)); s.textContent = this.on ? 'مفعّلة' : 'متوقفة';
  }
};
document.addEventListener('pointerdown', (e) => {
  Snd.init();
  const t = e.target.closest && e.target.closest('button, a.btn, a[href], [role="tab"], label.chip, label.btn, summary, input[type="checkbox"]');
  if (!t || t.disabled) return;
  Snd.play(t.dataset.snd || 'tap');
}, true);

/* ================= 3D background ================= */
const BG = (function () {
  const cv = $('#bg3d'), cx = cv.getContext('2d');
  let W = 0, H = 0, boxes = [], raf = 0, colors = [[11, 122, 108], [164, 69, 44], [200, 150, 46], [47, 75, 138]];
  let px = 0, py = 0, tpx = 0, tpy = 0, last = 0, enabled = store.get('mb.3d', true) !== false;
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const PAPER = [236, 228, 208];
  const FACES = [
    { n: [1, 0, 0], v: [1, 3, 7, 5], page: true }, { n: [-1, 0, 0], v: [0, 4, 6, 2], page: false },
    { n: [0, 1, 0], v: [2, 6, 7, 3], page: true }, { n: [0, -1, 0], v: [0, 1, 5, 4], page: true },
    { n: [0, 0, 1], v: [4, 5, 7, 6], page: false }, { n: [0, 0, -1], v: [0, 2, 3, 1], page: false }
  ];
  function hex(h) {
    h = String(h).trim();
    if (h[0] === '#') { if (h.length === 4) h = '#' + h[1] + h[1] + h[2] + h[2] + h[3] + h[3]; return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; }
    const m = h.match(/[\d.]+/g); return m ? m.slice(0, 3).map(Number) : [100, 100, 100];
  }
  function readColors() {
    const s = getComputedStyle(document.documentElement);
    colors = ['--b1', '--b2', '--b3', '--b4'].map((k) => hex(s.getPropertyValue(k)));
  }
  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth; H = window.innerHeight;
    cv.width = Math.floor(W * dpr); cv.height = Math.floor(H * dpr);
    cx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function mkBox(far) {
    const s = 0.55 + Math.random() * 0.55;
    return { x: (Math.random() - 0.5) * 15, y: (Math.random() - 0.5) * 10, z: far ? 15 + Math.random() * 3 : 2.5 + Math.random() * 13,
      rx: Math.random() * 6.28, ry: Math.random() * 6.28, rz: Math.random() * 6.28,
      vx: (Math.random() - 0.5) * 0.35, vy: (Math.random() - 0.5) * 0.35, vz: (Math.random() - 0.5) * 0.3,
      dy: 0.05 + Math.random() * 0.12, dz: -(0.15 + Math.random() * 0.25), s, c: Math.floor(Math.random() * 4) };
  }
  function init() { const n = W < 700 ? 20 : 36; boxes = []; for (let i = 0; i < n; i++) boxes.push(mkBox(false)); }
  function rot(p, rx, ry, rz) {
    let [x, y, z] = p, c, s, t;
    c = Math.cos(rx); s = Math.sin(rx); t = y * c - z * s; z = y * s + z * c; y = t;
    c = Math.cos(ry); s = Math.sin(ry); t = x * c + z * s; z = -x * s + z * c; x = t;
    c = Math.cos(rz); s = Math.sin(rz); t = x * c - y * s; y = x * s + y * c; x = t;
    return [x, y, z];
  }
  const L = (function () { const v = [0.3, -0.6, -0.75]; const m = Math.hypot(v[0], v[1], v[2]); return v.map((a) => -a / m); })();
  function drawBox(b, dark) {
    const w = 0.8 * b.s, h = 1.1 * b.s, d = 0.3 * b.s;
    const vs = [];
    for (let i = 0; i < 8; i++) {
      const r = rot([(i & 1 ? 1 : -1) * w, (i & 2 ? 1 : -1) * h, (i & 4 ? 1 : -1) * d], b.rx, b.ry, b.rz);
      vs.push([r[0] + b.x + px * b.z * 0.12, r[1] + b.y + py * b.z * 0.12, r[2] + b.z]);
    }
    const f = H * 0.95;
    const sc = vs.map((p) => [W / 2 + (p[0] / p[2]) * f, H / 2 + (p[1] / p[2]) * f]);
    const fog = Math.max(0, Math.min(1, 1 - (b.z - 3) / 15));
    const alpha = (dark ? 0.5 : 0.42) * (0.25 + 0.75 * fog);
    const cloth = colors[b.c];
    const faces = [];
    for (const fc of FACES) {
      const n = rot(fc.n, b.rx, b.ry, b.rz);
      let cz = 0, cxp = 0, cyp = 0;
      fc.v.forEach((i) => { cz += vs[i][2]; cxp += vs[i][0]; cyp += vs[i][1]; });
      cz /= 4; cxp /= 4; cyp /= 4;
      if (n[0] * cxp + n[1] * cyp + n[2] * cz >= 0) continue;
      const lit = 0.38 + 0.62 * Math.max(0, n[0] * L[0] + n[1] * L[1] + n[2] * L[2]);
      faces.push({ fc, z: cz, lit });
    }
    faces.sort((a, b2) => b2.z - a.z);
    for (const o of faces) {
      const base = o.fc.page ? PAPER : cloth;
      cx.beginPath();
      o.fc.v.forEach((i, k) => { if (k) cx.lineTo(sc[i][0], sc[i][1]); else cx.moveTo(sc[i][0], sc[i][1]); });
      cx.closePath();
      cx.fillStyle = 'rgba(' + Math.round(base[0] * o.lit) + ',' + Math.round(base[1] * o.lit) + ',' + Math.round(base[2] * o.lit) + ',' + alpha + ')';
      cx.fill();
      cx.strokeStyle = 'rgba(0,0,0,' + alpha * 0.35 + ')'; cx.lineWidth = 0.8; cx.stroke();
    }
  }
  function frame(ts) {
    raf = 0;
    if (!enabled || document.hidden) return;
    const dt = Math.min(0.05, (ts - last) / 1000 || 0.016); last = ts;
    px += (tpx - px) * 0.05; py += (tpy - py) * 0.05;
    cx.clearRect(0, 0, W, H);
    const dark = document.documentElement.getAttribute('data-theme') === 'dark' || (!document.documentElement.getAttribute('data-theme') && matchMedia('(prefers-color-scheme: dark)').matches);
    boxes.sort((a, b) => b.z - a.z);
    for (const b of boxes) {
      b.rx += b.vx * dt; b.ry += b.vy * dt; b.rz += b.vz * dt;
      b.y -= b.dy * dt; b.z += b.dz * dt;
      if (b.z < 2 || b.y < -7) { Object.assign(b, mkBox(true)); }
      drawBox(b, dark);
    }
    if (!reduce) raf = requestAnimationFrame(frame);
  }
  function start() { if (!raf && enabled) raf = requestAnimationFrame(frame); }
  function setEnabled(on) {
    enabled = !!on; store.set('mb.3d', enabled);
    document.body.classList.toggle('no3d', !enabled);
    const b = $('#set3d'); b.setAttribute('aria-pressed', String(enabled)); b.textContent = enabled ? 'مفعّلة' : 'متوقفة';
    if (enabled) start(); else if (raf) { cancelAnimationFrame(raf); raf = 0; }
  }
  function boot() {
    resize(); readColors(); init();
    window.addEventListener('resize', () => { resize(); });
    window.addEventListener('pointermove', (e) => { tpx = (e.clientX / W - 0.5) * 2; tpy = (e.clientY / H - 0.5) * 2; }, { passive: true });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) start(); });
    if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { readColors(); });
    document.body.classList.toggle('no3d', !enabled);
    start();
  }
  return { boot, setEnabled, readColors, get enabled() { return enabled; } };
})();

/* ================= theme ================= */
const Theme = {
  mode: store.get('mb.theme', 'auto'),
  apply() {
    const r = document.documentElement;
    if (this.mode === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', this.mode);
    const names = { auto: 'تلقائي', light: 'فاتح', dark: 'داكن' };
    $('#setTheme').textContent = names[this.mode];
    BG.readColors();
  },
  cycle() { this.mode = this.mode === 'auto' ? 'light' : this.mode === 'light' ? 'dark' : 'auto'; store.set('mb.theme', this.mode); this.apply(); toast('المظهر: ' + $('#setTheme').textContent); }
};

/* ================= auth (local, hashed) ================= */
const ITER = 210000;
const EMAIL = /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/;
const te = new TextEncoder();
const b64 = (buf) => btoa(String.fromCharCode.apply(null, new Uint8Array(buf)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function hashPw(pw, salt, iter) {
  if (!window.crypto || !crypto.subtle) throw new Error('nocrypto');
  const key = await crypto.subtle.importKey('raw', te.encode(pw), 'PBKDF2', false, ['deriveBits']);
  return crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256);
}
function ctEq(a, b) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
function pwScore(p) {
  let s = 0;
  if (p.length >= 8) s++; if (p.length >= 12) s++;
  if (/[a-z؀-ۿ]/i.test(p) && /[A-Z]/.test(p)) s++;
  if (/\d/.test(p)) s++; if (/[^A-Za-z0-9؀-ۿ]/.test(p)) s++;
  return Math.min(s, 4);
}
let authMode = 'login', user = null, lastActive = Date.now();

function authMsg(text, ok) {
  const m = $('#authMsg');
  if (!text) { m.hidden = true; return; }
  m.textContent = text; m.hidden = false; m.className = 'msg' + (ok ? ' ok' : '');
}
function setAuthMode(m) {
  authMode = m;
  $('#tabLogin').setAttribute('aria-selected', String(m === 'login'));
  $('#tabReg').setAttribute('aria-selected', String(m === 'register'));
  $('#nameField').hidden = m !== 'register';
  $('#pass2Field').hidden = m !== 'register';
  $('#meter').hidden = m !== 'register';
  $('#aPass').setAttribute('autocomplete', m === 'login' ? 'current-password' : 'new-password');
  $('#authSubmit').textContent = m === 'login' ? 'دخول' : 'إنشاء الحساب';
  authMsg('');
}
async function authSubmit() {
  authMsg('');
  const email = $('#aEmail').value.trim().toLowerCase();
  const pw = $('#aPass').value;
  if (!EMAIL.test(email)) { authMsg('اكتب بريدًا إلكترونيًا صحيحًا.'); return fail(); }
  if (!pw) { authMsg('اكتب كلمة المرور.'); return fail(); }
  const btn = $('#authSubmit'); btn.disabled = true;
  try {
    const users = store.get('mb.users', {});
    if (authMode === 'register') {
      const name = $('#aName').value.trim().slice(0, 40) || email.split('@')[0];
      if (users[email]) { authMsg('هذا البريد مسجّل من قبل. سجّل الدخول بدلًا من ذلك.'); return fail(); }
      if (pw.length < 8 || pwScore(pw) < 2) { authMsg('كلمة المرور ضعيفة. استخدم 8 أحرف على الأقل مع أرقام أو رموز.'); return fail(); }
      if (pw !== $('#aPass2').value) { authMsg('كلمتا المرور غير متطابقتين.'); return fail(); }
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const h = b64(await hashPw(pw, salt, ITER));
      users[email] = { name, salt: b64(salt), hash: h, iter: ITER, created: Date.now() };
      store.set('mb.users', users);
      Snd.play('ok');
      enter({ email, name });
    } else {
      const fails = store.get('mb.fails', {});
      const f = fails[email] || { n: 0, until: 0 };
      if (Date.now() < f.until) { authMsg('محاولات كثيرة. حاول بعد ' + Math.ceil((f.until - Date.now()) / 60000) + ' دقيقة.'); return fail(); }
      const u = users[email];
      const salt = u ? unb64(u.salt) : crypto.getRandomValues(new Uint8Array(16));
      const h = b64(await hashPw(pw, salt, u ? u.iter : ITER));
      if (!u || !ctEq(h, u.hash)) {
        f.n += 1;
        if (f.n >= 5) { f.until = Date.now() + 5 * 60000; f.n = 0; }
        fails[email] = f; store.set('mb.fails', fails);
        authMsg('البريد أو كلمة المرور غير صحيحة.'); return fail();
      }
      delete fails[email]; store.set('mb.fails', fails);
      Snd.play('ok');
      enter({ email, name: u.name });
    }
  } catch (e) {
    authMsg(e && e.message === 'nocrypto' ? 'متصفحك لا يدعم التشفير المطلوب لإنشاء الحسابات. استخدم «متابعة بدون حساب».' : 'حدث خطأ غير متوقع. حاول مرة أخرى.');
    fail();
  } finally { btn.disabled = false; $('#aPass').value = ''; $('#aPass2').value = ''; }
}
function fail() { Snd.play('err'); }

function enter(u) {
  user = u;
  sess.set({ email: u.email, name: u.name, guest: !!u.guest, ts: Date.now() });
  lastActive = Date.now();
  $('#auth').hidden = true; $('#app').hidden = false;
  $('#whoami').textContent = u.guest ? 'ضيف (بدون حساب)' : u.name + ' · ' + u.email;
  favs = store.get('mb.fav.' + u.email, []);
  hist = store.get('mb.hist.' + u.email, []);
  renderHistory(); renderSaved();
  const v = location.hash.slice(1);
  go(VIEWS.indexOf(v) >= 0 ? v : 'search', true);
}
function logout(msg) {
  sess.set(null); user = null;
  closeReader(true);
  $('#app').hidden = true; $('#auth').hidden = false;
  $('#results').replaceChildren(); seq++;
  setAuthMode('login'); $('#aEmail').value = '';
  if (msg) authMsg(msg, true);
  window.scrollTo(0, 0);
}
setInterval(() => { if (user && Date.now() - lastActive > 30 * 60000) { Snd.play('close'); logout('تم تسجيل خروجك تلقائيًا بعد فترة بلا نشاط.'); } }, 30000);
['pointerdown', 'keydown', 'scroll'].forEach((ev) => document.addEventListener(ev, () => { lastActive = Date.now(); }, { passive: true, capture: true }));

/* ================= navigation ================= */
const VIEWS = ['search', 'saved', 'open', 'about'];
function go(v, quiet) {
  if (VIEWS.indexOf(v) < 0) v = 'search';
  VIEWS.forEach((n) => { $('#v-' + n).hidden = n !== v; });
  $$('.nav button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.view === v)));
  if (v === 'saved') renderSaved();
  try { if (location.hash !== '#' + v) history.replaceState(null, '', '#' + v); } catch (e) { /* ignore */ }
  if (!quiet) window.scrollTo(0, 0);
}

/* ================= sources ================= */
const LANGN = { ar: 'العربية', en: 'English', fr: 'Français' };
const KINDN = { book: 'كتاب', article: 'مقال/بحث', thesis: 'مذكرة/أطروحة' };
const FMTN = { pdf: 'PDF', word: 'Word', web: 'ويب' };

async function getJson(url, ms) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms || 12000);
  try {
    const r = await fetch(url, { signal: ac.signal, credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}
function mk(o) {
  const pdf = safeUrl(o.pdf), page = safeUrl(o.page);
  const first = pdf || page;
  let fmt = pdf ? 'pdf' : 'web';
  if (/\.docx?(\?|#|$)/i.test(first)) fmt = 'word';
  return {
    id: o.src + ':' + (o.id || o.title), src: o.src, title: clean(o.title) || 'بدون عنوان',
    authors: (o.authors || []).filter(Boolean).slice(0, 3).map(clean).join('، '),
    year: o.year ? String(o.year).slice(0, 4) : '', kind: o.kind || '', lang: o.lang || '',
    pdf: pdf, page: page || pdf, fmt: fmt, guess: !!o.guess, sample: !!o.sample
  };
}
const OLL = { ar: 'ara', en: 'eng', fr: 'fre' };
const IAL = { ar: '(language:ara OR language:arabic OR language:ar)', en: '(language:eng OR language:english OR language:en)', fr: '(language:fre OR language:fra OR language:french OR language:fr)' };

const SOURCES = [
  { id: 'openalex', name: 'OpenAlex', note: 'ملايين المقالات والأطروحات والكتب', kinds: ['article', 'thesis', 'book'],
    fn: async (q, lang, type) => {
      const f = ['open_access.is_oa:true'];
      if (lang !== 'all') f.push('language:' + lang);
      if (type === 'thesis') f.push('type:dissertation'); else if (type === 'article') f.push('type:article'); else if (type === 'book') f.push('type:book|book-chapter');
      const j = await getJson('https://api.openalex.org/works?search=' + encodeURIComponent(q) + '&filter=' + f.join(',') + '&per-page=15&select=id,display_name,authorships,publication_year,type,best_oa_location,open_access,language');
      return (j.results || []).map((w) => {
        const loc = w.best_oa_location || {};
        const t = w.type || '';
        return mk({ src: 'openalex', id: w.id, title: w.display_name, authors: (w.authorships || []).map((a) => a.author && a.author.display_name), year: w.publication_year,
          kind: t === 'dissertation' ? 'thesis' : (t.indexOf('book') === 0 ? 'book' : 'article'), lang: w.language,
          pdf: loc.pdf_url, page: loc.landing_page_url || (w.open_access && w.open_access.oa_url) });
      }).filter((x) => x.pdf || x.page);
    } },
  { id: 'ol', name: 'Open Library', note: 'كتب كاملة قابلة للقراءة', kinds: ['book'],
    fn: async (q, lang) => {
      const j = await getJson('https://openlibrary.org/search.json?q=' + encodeURIComponent(q) + '&has_fulltext=true&limit=20&fields=key,title,author_name,first_publish_year,ia,ebook_access,language' + (lang !== 'all' ? '&language=' + OLL[lang] : ''));
      return (j.docs || []).filter((d) => d.ia && d.ia.length && d.ebook_access === 'public').map((d) => {
        const id = encodeURIComponent(d.ia[0]);
        return mk({ src: 'ol', id: d.key, title: d.title, authors: d.author_name, year: d.first_publish_year, kind: 'book',
          pdf: 'https://archive.org/download/' + id + '/' + id + '.pdf', page: 'https://archive.org/details/' + id, guess: true });
      });
    } },
  { id: 'ia', name: 'Internet Archive', note: 'أرشيف الكتب والمخطوطات', kinds: ['book', 'thesis'],
    fn: async (q, lang) => {
      const t = lucene(q); if (!t) return [];
      let qq = '(title:(' + t + ') OR creator:(' + t + ')) AND mediatype:texts AND NOT access-restricted-item:true';
      if (lang !== 'all') qq += ' AND ' + IAL[lang];
      const j = await getJson('https://archive.org/advancedsearch.php?q=' + encodeURIComponent(qq) + '&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=year&fl%5B%5D=language&sort%5B%5D=downloads+desc&rows=15&output=json');
      return ((j.response && j.response.docs) || []).map((d) => {
        const id = encodeURIComponent(d.identifier);
        return mk({ src: 'ia', id: d.identifier, title: d.title, authors: [].concat(d.creator || []), year: d.year, kind: 'book',
          pdf: 'https://archive.org/download/' + id + '/' + id + '.pdf', page: 'https://archive.org/details/' + id, guess: true });
      });
    } },
  { id: 'gb', name: 'Google Books', note: 'كتب مجانية كاملة', kinds: ['book'],
    fn: async (q, lang) => {
      const j = await getJson('https://www.googleapis.com/books/v1/volumes?q=' + encodeURIComponent(q) + '&filter=free-ebooks&printType=books&maxResults=20' + (lang !== 'all' ? '&langRestrict=' + lang : ''));
      return (j.items || []).map((it) => {
        const v = it.volumeInfo || {}, a = it.accessInfo || {};
        return mk({ src: 'gb', id: it.id, title: v.title, authors: v.authors, year: v.publishedDate, kind: 'book', lang: v.language,
          pdf: a.pdf && a.pdf.isAvailable ? a.pdf.downloadLink : '', page: a.webReaderLink || v.infoLink });
      }).filter((x) => x.pdf || x.page);
    } },
  { id: 'gut', name: 'Project Gutenberg', note: 'كتب كلاسيكية حرة', kinds: ['book'],
    fn: async (q, lang) => {
      const j = await getJson('https://gutendex.com/books/?search=' + encodeURIComponent(q) + '&languages=' + (lang === 'all' ? 'ar,en,fr' : lang));
      return (j.results || []).slice(0, 15).map((b) => {
        const fm = b.formats || {};
        const htmlKey = Object.keys(fm).filter((k) => k.indexOf('text/html') === 0)[0];
        return mk({ src: 'gut', id: String(b.id), title: b.title, authors: (b.authors || []).map((a) => a.name), kind: 'book', lang: (b.languages || [])[0],
          pdf: fm['application/pdf'], page: (htmlKey && fm[htmlKey]) || 'https://www.gutenberg.org/ebooks/' + b.id });
      });
    } },
  { id: 'hal', name: 'HAL', note: 'أطروحات وبحوث فرنسية', kinds: ['article', 'thesis', 'book'],
    fn: async (q, lang, type) => {
      const fq = ['openAccess_bool:true'];
      if (lang !== 'all') fq.push('language_s:' + lang);
      if (type === 'thesis') fq.push('docType_s:(THESE OR MEM OR HDR)'); else if (type === 'article') fq.push('docType_s:(ART OR COMM OR OUV OR COUV)'); else if (type === 'book') fq.push('docType_s:(OUV OR COUV)');
      const j = await getJson('https://api.archives-ouvertes.fr/search/?q=' + encodeURIComponent(q) + '&wt=json&rows=15&fl=title_s,authFullName_s,producedDateY_i,uri_s,fileMain_s,language_s,docType_s' + fq.map((x) => '&fq=' + encodeURIComponent(x)).join(''));
      return ((j.response && j.response.docs) || []).map((d) => {
        const dt = d.docType_s || '';
        return mk({ src: 'hal', id: d.uri_s, title: [].concat(d.title_s || [])[0], authors: d.authFullName_s, year: d.producedDateY_i,
          kind: /^(THESE|MEM|HDR)$/.test(dt) ? 'thesis' : (/^(OUV|COUV)$/.test(dt) ? 'book' : 'article'), lang: [].concat(d.language_s || [])[0], pdf: d.fileMain_s, page: d.uri_s });
      }).filter((x) => x.pdf || x.page);
    } },
  { id: 'doaj', name: 'DOAJ', note: 'مجلات علمية محكّمة مفتوحة', kinds: ['article'],
    fn: async (q) => {
      const t = lucene(q); if (!t) return [];
      const j = await getJson('https://doaj.org/api/search/articles/' + encodeURIComponent(t) + '?pageSize=15');
      return (j.results || []).map((r) => {
        const b = r.bibjson || {}, links = b.link || [];
        const full = links.filter((l) => l.type === 'fulltext')[0];
        const pdf = links.filter((l) => /pdf/i.test(l.content_type || ''))[0];
        return mk({ src: 'doaj', id: r.id, title: b.title, authors: (b.author || []).map((a) => a.name), year: b.year, kind: 'article',
          pdf: pdf && pdf.url, page: full && full.url });
      }).filter((x) => x.pdf || x.page);
    } },
  { id: 'epmc', name: 'Europe PMC', note: 'بحوث الطب والعلوم الحيوية', kinds: ['article'], langs: ['en'],
    fn: async (q) => {
      const j = await getJson('https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=' + encodeURIComponent(q + ' AND OPEN_ACCESS:y') + '&format=json&pageSize=15&resultType=lite');
      return ((j.resultList && j.resultList.result) || []).filter((r) => r.pmcid).map((r) =>
        mk({ src: 'epmc', id: r.pmcid, title: r.title, authors: r.authorString ? r.authorString.split(', ') : [], year: r.pubYear, kind: 'article', lang: 'en',
          pdf: 'https://europepmc.org/backend/ptpmcrender.fcgi?accid=' + encodeURIComponent(r.pmcid) + '&blobtype=pdf', page: 'https://europepmc.org/article/PMC/' + encodeURIComponent(r.pmcid) }));
    } }
];
const SRC = {}; SOURCES.forEach((s) => { SRC[s.id] = s; });
const enabled = new Set(store.get('mb.src', SOURCES.map((s) => s.id)).filter((id) => SRC[id]));

const ENGINES = [
  ['Google Scholar', (q) => 'https://scholar.google.com/scholar?q=' + q],
  ['Google (ملفات PDF)', (q) => 'https://www.google.com/search?q=' + q + '+filetype%3Apdf'],
  ['BASE', (q) => 'https://www.base-search.net/Search/Results?lookfor=' + q],
  ['Semantic Scholar', (q) => 'https://www.semanticscholar.org/search?q=' + q],
  ['CORE', (q) => 'https://core.ac.uk/search?q=' + q],
  ['Theses.fr', (q) => 'https://theses.fr/resultats?q=' + q],
  ['ويكي مصدر', (q) => 'https://ar.wikisource.org/w/index.php?search=' + q],
  ['ASJP المجلات الجزائرية', () => 'https://asjp.cerist.dz/'],
  ['المكتبة الشاملة', () => 'https://shamela.ws/']
];

/* ================= search ================= */
let seq = 0, buckets = {}, stat = {}, lastQ = '', favs = [], hist = [];
const EXAMPLES = ['الذكاء الاصطناعي', 'مناهج البحث العلمي', 'تسيير الموارد البشرية', 'machine learning', 'climate change', 'droit administratif'];
const SAMPLES = [
  mk({ src: 'sample', id: 'a', title: 'Attention Is All You Need', authors: ['Vaswani', 'Shazeer', 'Parmar'], year: 2017, kind: 'article', lang: 'en', pdf: 'https://arxiv.org/pdf/1706.03762', page: 'https://arxiv.org/abs/1706.03762', sample: true }),
  mk({ src: 'sample', id: 'b', title: "Alice's Adventures in Wonderland", authors: ['Lewis Carroll'], kind: 'book', lang: 'en', page: 'https://www.gutenberg.org/ebooks/11', sample: true }),
  mk({ src: 'sample', id: 'c', title: 'On the Origin of Species', authors: ['Charles Darwin'], year: 1859, kind: 'book', lang: 'en', page: 'https://www.gutenberg.org/ebooks/1228', sample: true })
];

function setStatus(text, cls) {
  const s = $('#status');
  if (!text) { s.hidden = true; return; }
  s.hidden = false; s.className = 'status' + (cls ? ' ' + cls : ''); s.textContent = text;
}
function selected() { return { type: $('input[name="type"]:checked').value, lang: $('input[name="lang"]:checked').value }; }
function active(type, lang) {
  return SOURCES.filter((s) => enabled.has(s.id) && (type === 'all' || s.kinds.indexOf(type) >= 0) && (lang === 'all' || !s.langs || s.langs.indexOf(lang) >= 0));
}
function renderSrcPicker() {
  const box = $('#srcList'); box.replaceChildren();
  SOURCES.forEach((s) => {
    const cb = el('input', { type: 'checkbox', id: 'src-' + s.id });
    cb.checked = enabled.has(s.id);
    cb.addEventListener('change', () => {
      if (cb.checked) enabled.add(s.id); else enabled.delete(s.id);
      store.set('mb.src', Array.from(enabled)); srcSummary();
    });
    box.append(el('label', { for: 'src-' + s.id }, cb, el('span', { text: s.name + ' — ' + s.note })));
  });
  srcSummary();
}
function srcSummary() { $('#srcSummary').textContent = 'المصادر (' + enabled.size + ' من ' + SOURCES.length + ')'; }

function renderHistory() {
  const h = $('#history'); h.replaceChildren();
  if (!hist.length) { h.hidden = true; return; }
  h.hidden = false;
  hist.forEach((q) => h.append(el('button', { type: 'button', class: 'chip-b', text: q, onclick: () => { $('#q').value = q; runSearch(q); } })));
  h.append(el('button', { type: 'button', class: 'chip-b clear', text: 'مسح السجل', onclick: () => { hist = []; store.set('mb.hist.' + user.email, hist); renderHistory(); } }));
}
function pushHistory(q) {
  hist = [q].concat(hist.filter((x) => x !== q)).slice(0, 8);
  if (user) store.set('mb.hist.' + user.email, hist);
  renderHistory();
}
function renderEngines(q) {
  const box = $('#engineLinks'); box.replaceChildren();
  const eq = encodeURIComponent(q || '');
  ENGINES.forEach((e) => {
    const u = e[1](eq);
    box.append(el('a', { class: 'btn', href: u, target: '_blank', rel: 'noopener noreferrer' }, el('span', { text: e[0] }), icon('ext')));
  });
  $('#engines').hidden = false;
}
function renderStatus(list) {
  const box = $('#srcStatus'); box.replaceChildren(); box.hidden = false;
  list.forEach((s) => {
    const st = stat[s.id] || { st: 'load', n: 0 };
    box.append(el('span', { class: 'pill ' + st.st, text: s.name + (st.st === 'ok' ? ' · ' + st.n : st.st === 'err' ? ' · تعذّر' : '') }));
  });
}
function merged() {
  const lists = Object.keys(buckets).map((k) => buckets[k]);
  const out = [], seen = new Set();
  let i = 0, more = true;
  while (more && out.length < 150) {
    more = false;
    for (const l of lists) {
      if (i < l.length) { more = true; const it = l[i], k = norm(it.title); if (k && !seen.has(k)) { seen.add(k); out.push(it); } }
    }
    i++;
  }
  return out.sort((a, b) => (b.pdf && !b.guess ? 2 : b.pdf ? 1 : 0) - (a.pdf && !a.guess ? 2 : a.pdf ? 1 : 0));
}
function isFav(it) { return favs.some((f) => f.id === it.id); }
function toggleFav(it, btn) {
  const i = favs.findIndex((f) => f.id === it.id);
  if (i >= 0) { favs.splice(i, 1); toast('أُزيل من المفضلة'); } else { favs.unshift(it); toast('أُضيف إلى المفضلة'); Snd.play('ok'); }
  if (user) store.set('mb.fav.' + user.email, favs);
  if (btn) btn.setAttribute('aria-pressed', String(isFav(it)));
  if (!$('#v-saved').hidden) renderSaved();
}
function card(it) {
  const srcName = it.sample ? 'عينة توضيحية' : (SRC[it.src] ? SRC[it.src].name : it.src);
  const badges = el('div', { class: 'badges' },
    it.sample ? el('span', { class: 'badge sample', text: 'عينة توضيحية' }) : null,
    el('span', { class: 'badge fmt', text: FMTN[it.fmt] || 'ويب' }),
    it.kind ? el('span', { class: 'badge', text: KINDN[it.kind] }) : null,
    it.lang ? el('span', { class: 'badge', text: LANGN[it.lang] || String(it.lang).toUpperCase().slice(0, 3) }) : null,
    it.sample ? null : el('span', { class: 'badge', text: srcName }));
  const meta = [it.authors, it.year].filter(Boolean).join(' · ');
  const star = el('button', { type: 'button', class: 'icon-btn star', 'aria-label': 'حفظ في المفضلة', 'aria-pressed': String(isFav(it)) }, icon('star'));
  star.addEventListener('click', () => toggleFav(it, star));
  const acts = el('div', { class: 'actions' });
  if (it.pdf || it.fmt === 'word') acts.append(el('button', { type: 'button', class: 'btn primary', onclick: () => openReader(it), 'data-snd': 'open' }, icon('file'), el('span', { text: 'قراءة' })));
  else if (it.page) acts.append(el('a', { class: 'btn primary', href: it.page, target: '_blank', rel: 'noopener noreferrer' }, icon('ext'), el('span', { text: 'فتح للقراءة' })));
  if (it.pdf) acts.append(el('a', { class: 'btn', href: it.pdf, target: '_blank', rel: 'noopener noreferrer', download: '' }, icon('download'), el('span', { text: 'تنزيل' })));
  if (it.page && it.pdf && it.page !== it.pdf) acts.append(el('a', { class: 'btn', href: it.page, target: '_blank', rel: 'noopener noreferrer' }, icon('ext'), el('span', { text: 'المصدر' })));
  acts.append(star);
  return el('li', { class: 'res', 'data-kind': it.kind || '' }, el('h4', { dir: 'auto', text: it.title }), meta ? el('div', { class: 'meta', dir: 'auto', text: meta }) : null, badges, acts);
}
function renderResults() {
  const ul = $('#results'); ul.replaceChildren();
  const items = merged();
  const frag = document.createDocumentFragment();
  items.forEach((it) => frag.append(card(it)));
  ul.append(frag);
  $('#intro').hidden = items.length > 0 || !!lastQ;
}
async function runSearch(raw) {
  const q = String(raw || '').trim().replace(/\s+/g, ' ').slice(0, 120);
  if (q.length < 2) { setStatus('اكتب حرفين على الأقل للبحث.', 'warn'); fail(); return; }
  const f = selected();
  const list = active(f.type, f.lang);
  if (!list.length) { setStatus('لا يوجد مصدر مفعّل يناسب هذا النوع واللغة. فعّل مصادر من قائمة «المصادر».', 'warn'); fail(); return; }
  const id = ++seq;
  lastQ = q; buckets = {}; stat = {};
  list.forEach((s) => { stat[s.id] = { st: 'load', n: 0 }; });
  pushHistory(q);
  setStatus('جارٍ البحث في ' + list.length + ' مصادر…');
  renderStatus(list); renderResults(); renderEngines(q);
  const btn = $('#goBtn'); btn.disabled = true;
  await Promise.all(list.map(async (s) => {
    try {
      const items = await s.fn(q, f.lang, f.type);
      if (id !== seq) return;
      buckets[s.id] = items; stat[s.id] = { st: 'ok', n: items.length };
    } catch (e) {
      if (id !== seq) return;
      stat[s.id] = { st: 'err', n: 0 };
    }
    renderStatus(list); renderResults();
  }));
  if (id !== seq) return;
  btn.disabled = false;
  const total = merged().length;
  const okCount = list.filter((s) => stat[s.id].st === 'ok').length;
  if (okCount === 0) {
    setStatus('تعذّر الاتصال بالمكتبات. تأكد من الإنترنت وحاول مجددًا. وإن كنت تعاين التطبيق داخل Claude فالاتصال الخارجي محجوب هنا، ويعمل بعد تحويله إلى تطبيق.', 'bad');
    $('#intro').hidden = true;
    const s = $('#status');
    s.append(document.createElement('br'), el('button', { type: 'button', class: 'btn small', onclick: showSamples }, el('span', { text: 'عرض عينة توضيحية للواجهة' })));
    fail();
  } else if (total === 0) {
    setStatus('لا نتائج مجانية لهذا البحث. جرّب كلمات أخرى أو لغة مختلفة، أو تابع في المحركات أسفل الصفحة.', 'warn'); fail();
  } else {
    setStatus('وجدنا ' + total + ' نتيجة مجانية لـ «' + q + '»' + (okCount < list.length ? ' (تعذّر بعض المصادر)' : '') + '.');
    Snd.play('ok');
  }
}
function showSamples() { seq++; buckets = { sample: SAMPLES }; setStatus('هذه عينة توضيحية لشكل النتائج وليست نتيجة بحث حقيقية.', 'warn'); $('#srcStatus').hidden = true; $('#goBtn').disabled = false; renderResults(); }
function renderSaved() {
  const ul = $('#savedList'); ul.replaceChildren();
  favs.forEach((it) => ul.append(card(it)));
  $('#savedEmpty').hidden = favs.length > 0;
}

/* ================= reader ================= */
const CDN = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/';
const R = { doc: null, scale: 1, base: null, item: null, token: 0, layout: 0, cur: 1, n: 0, obs: null, pgs: [], live: [], fit: true, file: null };
const rBody = $('#rBody'), rPages = $('#rPages'), rDoc = $('#rDoc'), rLoad = $('#rLoad'), rFrameBox = $('#rFrameBox');

function readerMode(m) {
  $('#rbar').dataset.mode = m;
  rPages.hidden = m !== 'pdf'; rDoc.hidden = m !== 'doc'; rFrameBox.hidden = m !== 'frame';
}
function resetReader() {
  R.token++;
  if (R.obs) { R.obs.disconnect(); R.obs = null; }
  if (R.doc) { try { R.doc.destroy(); } catch (e) { /* ignore */ } R.doc = null; }
  rPages.replaceChildren(); rDoc.replaceChildren(); rFrameBox.replaceChildren();
  R.pgs = []; R.live = []; R.file = null; R.cur = 1; R.n = 0;
  $('#rNote').hidden = true; rLoad.hidden = false; rLoad.textContent = 'جارٍ التحميل…';
}
function openShell(it) {
  Snd.play('open');
  resetReader();
  R.item = it;
  $('#rTitle').textContent = it.title;
  const ext = $('#rExt'); const u = it.page || it.pdf;
  if (u && !it.local) { ext.href = u; ext.hidden = false; } else ext.hidden = true;
  $('#reader').hidden = false; document.body.style.overflow = 'hidden';
  rBody.scrollTop = 0; readerMode('pdf');
  return R.token;
}
function closeReader(silent) {
  if ($('#reader').hidden) return;
  if (!silent) Snd.play('close');
  resetReader();
  $('#reader').hidden = true; document.body.style.overflow = '';
}
function note(text) { const n = $('#rNote'); n.textContent = text; n.hidden = !text; }

function fallbackFrame(it, why) {
  const t = R.token;
  const u = it.pdf || it.page;
  rLoad.hidden = true; readerMode('frame');
  note(why + ' نعرضه عبر عارض خارجي. وإن لم يظهر فاستخدم زر «الأصل» لفتحه في المتصفح.');
  if (!u) return;
  const fr = document.createElement('iframe');
  fr.title = it.title; fr.referrerPolicy = 'no-referrer';
  fr.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-popups');
  fr.src = 'https://docs.google.com/viewer?embedded=true&url=' + encodeURIComponent(u);
  if (t === R.token) rFrameBox.append(fr);
}
async function openReader(it) {
  const t = openShell(it);
  const u = it.pdf || it.page;
  try {
    if (!u) throw new Error('nourl');
    if (it.fmt === 'word') await loadWord({ url: u }, t);
    else await loadPdf({ url: u, withCredentials: false }, t);
  } catch (e) {
    if (t !== R.token) return;
    if (it.guess) { fallbackFrame(it, 'تعذّر تحميل الملف مباشرة، وقد لا يتوفر نسخة PDF لهذا المرجع.'); }
    else fallbackFrame(it, 'تعذّرت القراءة المباشرة بسبب قيود المصدر.');
  }
}
function sanitizeInto(html, target) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('script,style,iframe,object,embed,link,meta,form,base').forEach((n) => n.remove());
  doc.querySelectorAll('*').forEach((n) => {
    Array.from(n.attributes).forEach((a) => {
      const name = a.name.toLowerCase(), val = a.value.trim().toLowerCase();
      if (name.slice(0, 2) === 'on') n.removeAttribute(a.name);
      else if (name === 'href' && !/^(https:|#)/.test(val)) n.removeAttribute(a.name);
      else if (name === 'src' && !/^(data:image\/(png|jpe?g|gif|webp);base64,|https:)/.test(val)) n.removeAttribute(a.name);
      else if (name === 'style') n.removeAttribute(a.name);
    });
    if (n.tagName === 'A') { n.setAttribute('target', '_blank'); n.setAttribute('rel', 'noopener noreferrer'); }
  });
  target.replaceChildren(...Array.from(doc.body.childNodes).map((c) => document.importNode(c, true)));
}
async function loadWord(src, t) {
  if (!window.mammoth) throw new Error('nomammoth');
  let buf = src.data;
  if (!buf) {
    const r = await fetch(src.url, { credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    buf = await r.arrayBuffer();
  }
  if (t !== R.token) return;
  R.bytes = buf;
  const out = await mammoth.convertToHtml({ arrayBuffer: buf });
  if (t !== R.token) return;
  sanitizeInto(out.value, rDoc);
  rDoc.setAttribute('dir', 'auto');
  rLoad.hidden = true; readerMode('doc');
}
async function loadPdf(src, t) {
  if (!window.pdfjsLib) throw new Error('nopdfjs');
  pdfjsLib.GlobalWorkerOptions.workerSrc = CDN + 'pdf.worker.min.js';
  const task = pdfjsLib.getDocument(Object.assign({ isEvalSupported: false, enableXfa: false }, src));
  const pdf = await task.promise;
  if (t !== R.token) { try { pdf.destroy(); } catch (e) { /* ignore */ } return; }
  R.doc = pdf; R.n = pdf.numPages;
  const p1 = await pdf.getPage(1);
  R.base = p1.getViewport({ scale: 1 });
  R.fit = true;
  fitWidth();
  rLoad.hidden = true; readerMode('pdf');
  layoutPages(1);
}
function fitWidth() {
  const w = Math.max(240, rBody.clientWidth - 8);
  R.scale = Math.min(4, Math.max(0.4, w / R.base.width));
}
function layoutPages(goPage) {
  const lay = ++R.layout;
  if (R.obs) R.obs.disconnect();
  rPages.replaceChildren(); R.pgs = []; R.live = [];
  const w = R.base.width * R.scale, h = R.base.height * R.scale;
  const frag = document.createDocumentFragment();
  for (let i = 1; i <= R.n; i++) {
    const d = document.createElement('div');
    d.className = 'pg'; d.dataset.n = String(i);
    d.style.width = w + 'px'; d.style.height = h + 'px';
    R.pgs.push(d); frag.append(d);
  }
  rPages.append(frag);
  $('#rOf').textContent = '/ ' + R.n; $('#rPage').max = String(R.n);
  R.obs = new IntersectionObserver((es) => {
    es.forEach((e) => { if (e.isIntersecting) renderPage(Number(e.target.dataset.n), lay); });
  }, { root: rBody, rootMargin: '700px 0px' });
  R.pgs.forEach((d) => R.obs.observe(d));
  gotoPage(goPage || 1, true);
}
async function renderPage(n, lay) {
  const d = R.pgs[n - 1];
  if (!d || d.dataset.r || lay !== R.layout || !R.doc) return;
  d.dataset.r = '1';
  try {
    const page = await R.doc.getPage(n);
    if (lay !== R.layout) return;
    const v1 = page.getViewport({ scale: 1 });
    const css = (R.base.width * R.scale) / v1.width;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const vp = page.getViewport({ scale: css * dpr });
    const c = document.createElement('canvas');
    c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
    c.style.width = (vp.width / dpr) + 'px'; c.style.height = (vp.height / dpr) + 'px';
    await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
    if (lay !== R.layout) return;
    d.style.height = c.style.height;
    d.replaceChildren(c);
    R.live.push(n);
    while (R.live.length > 8) {
      let far = 0, fi = 0;
      R.live.forEach((x, i) => { const dist = Math.abs(x - R.cur); if (dist > far) { far = dist; fi = i; } });
      const old = R.live.splice(fi, 1)[0];
      const od = R.pgs[old - 1]; if (od) { od.replaceChildren(); delete od.dataset.r; }
    }
  } catch (e) { delete d.dataset.r; }
}
function gotoPage(n, quiet) {
  n = Math.max(1, Math.min(R.n, Math.floor(Number(n)) || 1));
  R.cur = n; $('#rPage').value = String(n);
  const d = R.pgs[n - 1];
  if (d) rBody.scrollTop = d.offsetTop - rBody.offsetTop - 6;
  if (!quiet) Snd.play('page');
}
let scrollRaf = 0;
rBody.addEventListener('scroll', () => {
  if (scrollRaf || !R.pgs.length) return;
  scrollRaf = requestAnimationFrame(() => {
    scrollRaf = 0;
    const top = rBody.scrollTop + rBody.clientHeight * 0.3 + rBody.offsetTop;
    let cur = 1;
    for (let i = 0; i < R.pgs.length; i++) { if (R.pgs[i].offsetTop <= top) cur = i + 1; else break; }
    if (cur !== R.cur) { R.cur = cur; $('#rPage').value = String(cur); }
  });
}, { passive: true });
function zoom(f) {
  if (!R.doc) return;
  R.fit = false;
  R.scale = Math.min(4, Math.max(0.4, R.scale * f));
  layoutPages(R.cur);
}
function saveBlob(blob, name) {
  const a = document.createElement('a');
  const u = URL.createObjectURL(blob);
  a.href = u; a.download = name; a.rel = 'noopener';
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 5000);
}
function fname(t, ext) { return (String(t || 'document').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').trim().slice(0, 80) || 'document') + '.' + ext; }
async function readerDownload() {
  const it = R.item; if (!it) return;
  try {
    if (R.file) { saveBlob(R.file, R.file.name); toast('بدأ التنزيل'); Snd.play('ok'); return; }
    if (R.doc) { const data = await R.doc.getData(); saveBlob(new Blob([data], { type: 'application/pdf' }), fname(it.title, 'pdf')); toast('بدأ التنزيل'); Snd.play('ok'); return; }
    if (R.bytes) { saveBlob(new Blob([R.bytes]), fname(it.title, 'docx')); toast('بدأ التنزيل'); Snd.play('ok'); return; }
  } catch (e) { /* fall through */ }
  const u = it.pdf || it.page;
  if (u) { const a = el('a', { href: u, target: '_blank', rel: 'noopener noreferrer', download: '' }); document.body.append(a); a.click(); a.remove(); toast('فُتح رابط التنزيل في المتصفح'); }
  else { toast('لا يوجد رابط تنزيل لهذا المرجع', true); fail(); }
}

/* local files + direct links */
async function openLocal(file) {
  if (!file) return;
  const name = file.name || 'ملف';
  const ext = (name.split('.').pop() || '').toLowerCase();
  if (file.size > 200 * 1024 * 1024) { toast('الملف كبير جدًا (الحد 200 ميغابايت).', true); fail(); return; }
  if (['pdf', 'docx', 'txt'].indexOf(ext) < 0) { toast(ext === 'doc' ? 'صيغة doc القديمة غير مدعومة. احفظه بصيغة docx أو PDF.' : 'الصيغة غير مدعومة. اختر PDF أو docx أو txt.', true); fail(); return; }
  const it = { id: 'local:' + name, title: name, local: true, fmt: ext === 'pdf' ? 'pdf' : 'word' };
  const t = openShell(it);
  R.file = file;
  try {
    const buf = await file.arrayBuffer();
    if (t !== R.token) return;
    if (ext === 'pdf') await loadPdf({ data: new Uint8Array(buf) }, t);
    else if (ext === 'docx') await loadWord({ data: buf }, t);
    else {
      const txt = new TextDecoder('utf-8').decode(buf);
      rDoc.replaceChildren(el('pre', { dir: 'auto', text: txt }));
      rLoad.hidden = true; readerMode('doc');
    }
  } catch (e) {
    if (t !== R.token) return;
    rLoad.hidden = false; rLoad.textContent = 'تعذّر فتح الملف. قد يكون تالفًا أو محميًا بكلمة مرور.'; fail();
  }
}
function openUrl(raw) {
  const m = $('#urlMsg');
  const u = safeUrl(raw);
  if (!u) { m.textContent = 'اكتب رابطًا صحيحًا يبدأ بـ https://'; m.hidden = false; fail(); return; }
  m.hidden = true;
  let title = u;
  try { title = decodeURIComponent(new URL(u).pathname.split('/').filter(Boolean).pop() || new URL(u).hostname); } catch (e) { /* keep */ }
  const it = { id: 'url:' + u, title: title, pdf: u, page: u, fmt: /\.docx(\?|#|$)/i.test(u) ? 'word' : 'pdf' };
  openReader(it);
}

/* ================= wiring ================= */
function boot() {
  BG.boot();
  Theme.apply();
  Snd.set(Snd.on);
  BG.setEnabled(BG.enabled);

  // auth
  $$('[data-auth]').forEach((b) => b.addEventListener('click', () => setAuthMode(b.dataset.auth)));
  $('#authForm').addEventListener('submit', (e) => { e.preventDefault(); authSubmit(); });
  $('#guestBtn').addEventListener('click', () => { Snd.play('ok'); enter({ email: 'guest', name: 'ضيف', guest: true }); });
  $('#togglePass').addEventListener('click', (e) => {
    const p = $('#aPass'), show = p.type === 'password';
    p.type = show ? 'text' : 'password'; e.currentTarget.textContent = show ? 'إخفاء' : 'إظهار'; e.currentTarget.setAttribute('aria-pressed', String(show));
  });
  $('#aPass').addEventListener('input', () => {
    if (authMode !== 'register') return;
    const s = pwScore($('#aPass').value);
    $('#meter').dataset.level = String(s);
    $('#meterTxt').textContent = ['8 أحرف على الأقل، مع أرقام أو رموز', 'ضعيفة', 'مقبولة', 'جيدة', 'قوية'][s];
  });

  // nav + top
  $$('.nav button').forEach((b) => b.addEventListener('click', () => go(b.dataset.view)));
  $('#btnSound').addEventListener('click', () => { Snd.init(); Snd.set(!Snd.on); Snd.play('tap'); });
  $('#setSound').addEventListener('click', () => { Snd.set(!Snd.on); Snd.play('tap'); });
  $('#set3d').addEventListener('click', () => BG.setEnabled(!BG.enabled));
  $('#btnTheme').addEventListener('click', () => Theme.cycle());
  $('#setTheme').addEventListener('click', () => Theme.cycle());
  window.addEventListener('hashchange', () => { const v = location.hash.slice(1); if (user && VIEWS.indexOf(v) >= 0) go(v, true); });

  // search
  renderSrcPicker();
  const ex = $('#examples');
  EXAMPLES.forEach((t) => ex.append(el('button', { type: 'button', text: t, onclick: () => { $('#q').value = t; runSearch(t); } })));
  $('#searchForm').addEventListener('submit', (e) => { e.preventDefault(); runSearch($('#q').value); });
  const ab = $('#aboutSources');
  SOURCES.forEach((s) => ab.append(el('li', {}, el('b', { text: s.name }), ' — ' + s.note)));

  // open file
  $('#fileIn').addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; e.target.value = ''; openLocal(f); });
  const drop = $('#drop');
  ['dragenter', 'dragover'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => { const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; openLocal(f); });
  $('#urlForm').addEventListener('submit', (e) => { e.preventDefault(); openUrl($('#urlIn').value); });

  // reader
  $('#rClose').addEventListener('click', () => closeReader());
  $('#rPrev').addEventListener('click', () => gotoPage(R.cur - 1));
  $('#rNext').addEventListener('click', () => gotoPage(R.cur + 1));
  $('#rPage').addEventListener('change', (e) => gotoPage(e.target.value));
  $('#rZin').addEventListener('click', () => zoom(1.2));
  $('#rZout').addEventListener('click', () => zoom(1 / 1.2));
  $('#rFit').addEventListener('click', () => { if (!R.doc) return; R.fit = true; fitWidth(); layoutPages(R.cur); });
  $('#rDl').addEventListener('click', readerDownload);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeReader(); });
  let rz = 0;
  window.addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(() => { if (R.doc && R.fit && !$('#reader').hidden) { fitWidth(); layoutPages(R.cur); } }, 250); });

  // account
  $('#logoutBtn').addEventListener('click', () => { Snd.play('close'); logout('تم تسجيل الخروج.'); });
  $('#delBtn').addEventListener('click', () => {
    if (!user || user.guest) { toast('لا يوجد حساب لحذفه. سجّل الخروج فقط.'); return; }
    const box = $('#delBox'); box.replaceChildren(
      el('span', { class: 'fine', text: 'سيُحذف حسابك ومفضلتك نهائيًا. هل أنت متأكد؟' }),
      el('button', { type: 'button', class: 'btn danger small', text: 'نعم، احذف', onclick: () => {
        const users = store.get('mb.users', {}); delete users[user.email]; store.set('mb.users', users);
        store.set('mb.fav.' + user.email, []); store.set('mb.hist.' + user.email, []);
        Snd.play('err'); logout('تم حذف الحساب وبياناته.');
        box.replaceChildren(el('button', { type: 'button', class: 'btn danger', id: 'delBtn', text: 'حذف حسابي وبياناتي' }));
        setTimeout(() => location.reload(), 600);
      } }),
      el('button', { type: 'button', class: 'btn small', text: 'تراجع', onclick: () => { box.replaceChildren(el('button', { type: 'button', class: 'btn danger', id: 'delBtn', text: 'حذف حسابي وبياناتي' })); location.reload(); } }));
  });

  // restore session
  const s = sess.get();
  if (s && s.email && Date.now() - (s.ts || 0) < 30 * 60000) enter({ email: s.email, name: s.name, guest: s.guest });
  else { $('#auth').hidden = false; setAuthMode('login'); }

  // offline support in the installed app
  if ('serviceWorker' in navigator && location.protocol === 'https:' && !document.querySelector('meta[name="claude:viewport-fit-sides"]')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
